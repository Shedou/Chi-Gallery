GPU Caps Viewer
Graphics Card Information Utility
GPU Capabilities Viewer & OpenGL / OpenCL API Support
Copyright � 2007-2010 Jerome 'JeGX' Guinot, All rights reserved.
http://www.oZone3D.Net

GPU Caps Viewer is a freeware video card information utility that quickly describes 
the essential capabilities of your graphics card/GPU including GPU type, amount of 
VRAM , OpenGL, OpenCL and CUDA API support level, OpenGL API extensions database and general 
system configuration, as well as a GPU-Stress-Test functionality (GPU-Burner).

Visit GPU Caps Viewer homepage at http://www.oZone3D.net/gpu_caps_viewer/
for new updates and ChangeLog.

GPU Caps Viewer uses the ZoomGPU engine to retrieve graphics card data. 
More information about ZoomGPU: http://www.ozone3d.net/zoomgpu/

Enjoy!
.:JeGX:.