These scripts should be copied in GPU Caps Viewer root directory in order to work properly.
They have been put in that folder to make the root folder cleaner.