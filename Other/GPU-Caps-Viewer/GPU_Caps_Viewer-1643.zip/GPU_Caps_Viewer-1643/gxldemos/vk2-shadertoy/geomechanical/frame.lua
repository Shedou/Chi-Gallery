
if (gh_vk.swapchain_has_changed() == 1) then
  winW, winH = gh_window.getsize(0)

  kx_resize()

  local w2 = winW/2
  local h2 = winH/2
  gh_camera.update_ortho(camera_ortho, -w2, w2, -h2, h2, 1.0, 10.0)
  gh_camera.set_viewport(camera_ortho, 0, 0, winW, winH)
    
  UpdateCameraTransform(ub1, camera_ortho)
  gh_mesh.update_quad_size(mesh, winW, winH)
  
end  





-----------------------------------------------------------------------
kx_frame_begin(0.2, 0.2, 0.2)
-----------------------------------------------------------------------


local elapsed_time = kx_gettime()

UpdateParam1(ub1, winW, winH, elapsed_time)

gh_vk.descriptorset_bind(ds)
gh_vk.pipeline_bind(pso01)
gh_object.render(mesh)


-----------------------------------------------------------------------
kx_frame_end(1)
-----------------------------------------------------------------------

