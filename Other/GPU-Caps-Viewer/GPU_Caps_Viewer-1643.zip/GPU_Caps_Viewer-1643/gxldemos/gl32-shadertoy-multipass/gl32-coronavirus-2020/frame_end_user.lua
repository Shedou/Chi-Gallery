
local display_imgui = false

if (display_imgui and (display_info == 1)) then
  ----------------------------------------------------------------------------
  -- ImGui begin -------------------------------------------------------------
  --
  imgui_frame_begin()

  --gh_imgui.set_color(IMGUI_TITLE_BG_COLOR, 0.4, 0.4, 0.4, 0.90)


  local window_default = 0
  local window_no_resize = 2
  local window_no_move = 4
  local window_no_collapse = 32
  local window_show_border = 128
  local window_no_save_settings = 256
  local pos_size_flag_always = 1 -- Always set the pos and/or size
  local pos_size_flag_once = 2 -- Set the pos and/or size once per runtime session (only the first call with succeed)
  local pos_size_flag_first_use_ever = 4  -- Set the pos and/or size if the window has no saved data (if doesn't exist in the .ini file)
  local pos_size_flag_appearing = 8  -- Set the pos and/or size if the window is appearing after being hidden/inactive (or the first time)

  local window_flags = window_default | window_no_resize | window_no_move

  local is_open = gh_imgui.window_begin("Control panel", 300, 200, 10, 10, window_flags, pos_size_flag_always, pos_size_flag_always)
  --local is_open = imgui_window_begin_v1("Control panel", 360, 560, 20, 20)
  if (is_open == 1) then

    --gh_imgui.set_color(IMGUI_TITLE_BG_ACTIVE_COLOR, 0.05, 0.05, 0.1, 0.90)

    local window_w = gh_imgui.get_content_region_available_width()

    local widget_width = window_w * 1.0
    
    
    gh_imgui.text("Press [ESC] to quit the demo")
    
    ---[[

    imgui_vertical_space()
    imgui_vertical_space()


    gh_imgui.push_item_width(widget_width)

    --[[
    gh_imgui.text("Simulation speed factor")
    local min_value = 1.0
    local max_value = 200.0
    local power = 1.0
    g_simulation_speed_factor = gh_imgui.slider_1f("##simspeed", g_simulation_speed_factor,   min_value, max_value,   power)

    imgui_vertical_space()
    imgui_vertical_space()
    --]]

    --[[
    gh_imgui.text("Albedo color")
    albedo_color.r, albedo_color.g, albedo_color.b, albedo_color.a = gh_imgui.color_edit_rgba("##colorpicker-albedo", albedo_color.r, albedo_color.g, albedo_color.b, albedo_color.a)
    
    imgui_vertical_space()
    imgui_vertical_space()

    gh_imgui.text("Ambient color")
    ambient_color.r, ambient_color.g, ambient_color.b, ambient_color.a = gh_imgui.color_edit_rgba("##colorpicker-ambient", ambient_color.r, ambient_color.g, ambient_color.b, ambient_color.a)

    imgui_vertical_space()
    imgui_vertical_space()

    gh_imgui.text("Sky color")
    sky_color.r, sky_color.g, sky_color.b, sky_color.a = gh_imgui.color_edit_rgba("##colorpicker-sky", sky_color.r, sky_color.g, sky_color.b, sky_color.a)
    --]]

    gh_imgui.pop_item_width()
    --]]


  end 

  imgui_window_end()

  imgui_frame_end()
  --
  -- ImGui end ---------------------------------------------------------------
  ----------------------------------------------------------------------------
  --]]
end

