
uReset = 1

