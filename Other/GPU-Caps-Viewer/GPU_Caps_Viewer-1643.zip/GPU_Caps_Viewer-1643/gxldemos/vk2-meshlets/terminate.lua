
-- Unmap the GPU buffer.
--
--gh_gpu_buffer.unmap(font_ub)


