	
   
local elapsed_time = gh_utils.get_elapsed_time()

--gh_object.set_euler_angles(mesh, ang_x + elapsed_time * 3.0, elapsed_time * 7.0, elapsed_time * 11.0)
UpdateTransformBuffer_Object()




if (gh_vk.swapchain_has_changed() == 1) then

  local aspect = winW / winH
  gh_camera.update_persp(camera, camera_params.fov, aspect, camera_params.znear, camera_params.zfar)
  gh_camera.set_viewport(camera, 0, 0, winW, winH)
  UpdateTransformBuffer_Camera()
  --[[
  if (display_imgui == 0) then
    local ai = gh_vk.frame_get_active_command_buffer_index()
    for i=0, swapchain_image_count-1 do
      gh_vk.frame_set_active_command_buffer_index(i)
      build_command_buffer(winW, winH)
    end
    gh_vk.frame_set_active_command_buffer_index(ai)
  end
  --]]

end



-- Only rebuild command buffers (one command buffer per frame) every frame if ImGui is used.
--
if (display_imgui == 1) then
  build_command_buffer(winW, winH)
end






