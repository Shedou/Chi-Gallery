	
   
local elapsed_time = gh_utils.get_elapsed_time()


-- Updates object transformation.
--
--gh_object.set_euler_angles(mesh, elapsed_time * 3.0, elapsed_time * 5.0, elapsed_time * 7.0)
gh_object.set_euler_angles(mesh, 90.0 + 10.0 * math.cos(elapsed_time * 2.0), 0.0, 10.0 * math.sin(elapsed_time * 2.0))
gh_object.set_position(mesh, 0.0, 0.0, 0.0)
UpdateObjectTransform(ub1, mesh)




if (gh_vk.swapchain_has_changed() == 1) then
  local index = gh_vk.frame_get_active_command_buffer_index()
  for i=0, max_concurrent_frames-1 do
    gh_vk.frame_set_active_command_buffer_index(i)
    build_command_buffer(winW, winH)
  end
  gh_vk.frame_set_active_command_buffer_index(index)
end




build_command_buffer(winW, winH)




