

kx_frame_begin(0.0, 0.0, 0.0)

kx_check_input()


local elapsed_time = kx_gettime()

local mx, my = kx_mouse_get_position()
my = winH - my

local button_state = gh_input.mouse_get_button_state(1)
		
gh_camera.bind(g_camera_ortho)

gh_renderer.set_depth_test_state(0)

gh_gpu_program.bind(shadertoy_prog)
gh_gpu_program.uniform3f(shadertoy_prog, "iResolution", winW, winH, 0.0)
gh_gpu_program.uniform1f(shadertoy_prog, "iTime", elapsed_time)
gh_gpu_program.uniform4f(shadertoy_prog, "iMouse", mx, my, button_state, 0)

gh_gpu_program.uniform1i(shadertoy_prog, "iFrame", frame_counter)
frame_counter = frame_counter + 1


