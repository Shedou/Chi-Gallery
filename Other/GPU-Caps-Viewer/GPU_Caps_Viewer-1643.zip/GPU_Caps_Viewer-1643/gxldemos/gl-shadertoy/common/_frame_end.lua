

gh_object.render(g_quad)




if (display_imgui_params) then
  imgui_frame_begin()
  local is_open = imgui_window_begin_pos_size_once("Shadertoy params", 300, 200, 20, 20)
  if (is_open == 1) then
    
    if (_G['ImGuiDemoParams'] ~= nil) then
      ImGuiDemoParams()
    end

  end
  imgui_window_end()
  imgui_frame_end()
end





local show_osi = kx_get_osi_state()

kx_frame_end(show_osi)
