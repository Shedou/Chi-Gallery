
local elapsed_time = gh_utils.get_elapsed_time()





if (gh_vk.swapchain_has_changed() == 1) then
  winW, winH = gh_window.getsize(0)

  local aspect = winW / winH
  gh_camera.update_persp(camera, camera_params.fov, aspect, camera_params.znear, camera_params.zfar)
  gh_camera.set_viewport(camera, 0, 0, winW, winH)

  for i=0, swapchain_image_count-1 do
    local ub = ubs[i+1]
    gh_gpu_buffer.map(ub)
    UpdateCameraTransform(ub, camera)
    gh_gpu_buffer.unmap(ub)
  end

end








update_scene(elapsed_time)

build_command_buffer(winW, winH)


--render_scene_mode = 2

--[[
if (render_scene_mode == 2) then

  if (gh_vk.swapchain_has_changed() == 1) then

    winW, winH = gh_window.getsize(0)

    local aspect = winW / winH
    gh_camera.update_persp(camera, camera_params.fov, aspect, camera_params.znear, camera_params.zfar)
    gh_camera.set_viewport(camera, 0, 0, winW, winH)

    UpdateCameraTransform(ub1, camera)    
    
    local index = gh_vk.frame_get_active_command_buffer_index()
    for i=0, swapchain_image_count-1 do
      gh_vk.frame_set_active_command_buffer_index(i)
      build_command_buffer(winW, winH)
    end
    gh_vk.frame_set_active_command_buffer_index(index)
    print("***************** COMMAND BUFFERS REBUILT ***********************")
  end


else

  if (gh_vk.swapchain_has_changed() == 1) then

    winW, winH = gh_window.getsize(0)

    local aspect = winW / winH
    gh_camera.update_persp(camera, camera_params.fov, aspect, camera_params.znear, camera_params.zfar)
    gh_camera.set_viewport(camera, 0, 0, winW, winH)

    UpdateCameraTransform(ub1, camera)    
  end



  build_command_buffer(winW, winH)

end
--]]