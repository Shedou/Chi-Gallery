
local elapsed_time = gh_utils.get_elapsed_time()


draw_scene(winW, winH, elapsed_time)


--[[
gh_camera.set_position(camera, 0, 0, 20)
gh_camera.set_lookat(camera, 0, 0, 0, 1)

gh_camera.bind(camera)


gh_renderer.clear_color_depth_buffers(0.2, 0.25, 0.30, 1.0, 1.0)

gh_texture.bind(tex0, 0)
  
gh_gpu_program.bind(gpu_prog)



local num_x = 40
local num_y = 40
local size_x = 40.0
local size_y = 20.0

local step_x = size_x / num_x
local step_y = size_y / num_y

local pos_y = -size_y / 2.0

for y=0, num_y do

  local pos_x = -size_x / 2.0

  for x=0, num_x do

    gh_object.set_euler_angles(mesh, elapsed_time * 3.0 + x, elapsed_time * 7.0 + y, elapsed_time * 11.0)
    gh_object.set_position(mesh, pos_x, pos_y, 0.0)
    pos_x = pos_x + step_x

    gh_object.render(mesh)

  end

  pos_y = pos_y + step_y
end
--]]

