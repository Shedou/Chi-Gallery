local elapsed_time = gh_utils.get_elapsed_time()
local dt = gh_utils.get_time_step()

frames = frames+1
fps_time = fps_time + dt
if (fps_time >= 1.0) then
  fps_time = 0
  fps = frames
  frames = 0
end  









gh_camera.bind(camera)


gh_renderer.clear_color_depth_buffers(0.2, 0.2, 0.2, 1.0, 1.0)
gh_renderer.set_depth_test_state(1)



if (GL_ARB_gl_spirv_OK == 1) then

  gh_object.set_euler_angles(quad, 0, elapsed_time*33.0, 0)


  gh_gpu_buffer.map(ub)
  ShaderBufferUpdateObject(ub, quad)    
  gh_gpu_buffer.unmap(ub)

  gh_texture.bind(tex0, 0)

  gh_gpu_program.bind(texture_prog)
  gh_object.render(quad)

end






---[[
  libfont_clear()

  local y_offset = 40
  
  libfont_print(20, y_offset, 1, 0.5, 0, 1, "GL_ARB_gl_spirv demo")
  y_offset = y_offset + 20


  if (GL_ARB_gl_spirv_OK == 0) then
    y_offset = y_offset + 20
    libfont_print(20, y_offset, 1, 0.25, 0, 1, "**** GL_ARB_gl_spirv NOT SUPPORTED ****")
    y_offset = y_offset + 20
  end
  
  y_offset = y_offset + 20
  libfont_print(20, y_offset, 1, 1, 0, 1, string.format("Rendering speed: %d FPS / %.03f ms", fps, dt*1000))
  y_offset = y_offset + 20
  
  y_offset = y_offset + 20
  libfont_print(20, y_offset, 1, 1, 0, 1, "GL_RENDERER")
  y_offset = y_offset + 20
  libfont_print(20, y_offset, 1, 1, 1, 1, "> " .. gl_renderer)
  y_offset = y_offset + 20
  
  libfont_print(20, y_offset, 1, 1, 0, 1, "GL_VERSION")
  y_offset = y_offset + 20
  libfont_print(20, y_offset, 1, 1, 1, 1, "> " .. gl_version)
  y_offset = y_offset + 20
  
  
  libfont_render()
  --]]
  
  



