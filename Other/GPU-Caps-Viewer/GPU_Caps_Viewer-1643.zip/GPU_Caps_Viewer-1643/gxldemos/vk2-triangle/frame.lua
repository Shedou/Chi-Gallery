	
   
local elapsed_time = gh_utils.get_elapsed_time()

local cmdbuf_index = gh_vk.frame_get_active_command_buffer_index()


if (gh_vk.swapchain_has_changed() == 1) then
  winW, winH = gh_window.getsize(0)

  local aspect = winW / winH
  gh_camera.update_persp(camera, camera_params.fov, aspect, camera_params.znear, camera_params.zfar)
  gh_camera.set_viewport(camera, 0, 0, winW, winH)
  UpdateCameraTransform(camera, ub1)
  
  local ai = gh_vk.frame_get_active_command_buffer_index()
  for i=0, max_concurrent_frames-1 do
    gh_vk.frame_set_active_command_buffer_index(i)
    build_command_buffer(winW, winH)
  end
  gh_vk.frame_set_active_command_buffer_index(ai)
end





-- Updates object transformation.
--
gh_object.set_euler_angles(triangle, 0, elapsed_time*33.0, 0)
UpdateObjectTransform(triangle, ub1)


build_command_buffer(winW, winH)
