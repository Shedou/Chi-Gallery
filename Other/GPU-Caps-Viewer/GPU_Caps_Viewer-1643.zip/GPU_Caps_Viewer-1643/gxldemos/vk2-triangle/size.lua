

    
winW, winH = gh_window.getsize(0)


