
-- Unmap the GPU buffer.
--
gh_gpu_buffer.unmap(ub1)


