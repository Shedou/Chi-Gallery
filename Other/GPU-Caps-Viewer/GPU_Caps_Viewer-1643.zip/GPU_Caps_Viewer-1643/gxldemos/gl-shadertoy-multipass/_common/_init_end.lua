
kx_init_end()

