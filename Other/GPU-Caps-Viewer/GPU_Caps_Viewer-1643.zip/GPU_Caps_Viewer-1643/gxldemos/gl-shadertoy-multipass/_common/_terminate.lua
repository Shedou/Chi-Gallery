
kx_terminate()

